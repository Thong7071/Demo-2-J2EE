# Demo 2 – RAG (polished, layout như Demo 1)
**Mục tiêu:** PDF → chunk → embeddings (Gemini) → retrieve (cosine) → chat (Gemini) với giao diện web tối giản, giữ layout và thói quen `.env` của Demo 1.

## Cấu trúc
- `com.example.demo.config.CorsConfig` – CORS cho web UI
- `com.example.demo.controller.ChatController` – `POST /api/rag/reindex`, `POST /api/rag/ask`
- `com.example.demo.controller.GlobalExceptionHandler` – Chuẩn hóa lỗi JSON
- `com.example.demo.model` – DTOs
- `com.example.demo.service.*` – Gemini REST, PDF loader, chunker, vector store, RAG service
- `src/main/resources/static/index.html` – UI upload PDF + hỏi/đáp, dark/light

## Chạy
```bash
cp config-template.properties .env
# Sửa .env: GEMINI_API_KEY=...

mvn spring-boot:run
# hoặc
mvn clean package && java -jar target/demo-2-rag-0.0.1-SNAPSHOT.jar
```
**Health check:** `GET /actuator/health`

## API
### `POST /api/rag/reindex` (multipart/form-data)
Field: `file` (PDF). → Trả `{chunks, vectors, millis}`

### `POST /api/rag/ask`
Body:
```json
{ "question": "..." }
```
Response:
```json
{ "answer": "...", "sources": [ { "chunkId": 12, "score": 0.83 }, ... ] }
```

## Ghi chú
- Vector store **in-memory** (demo). Có thể thay bằng PGVector/SQLite.
- Nếu mạng/API lỗi → bắt exception trả lỗi JSON có mã và message rõ ràng.
