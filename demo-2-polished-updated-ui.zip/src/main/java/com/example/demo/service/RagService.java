package com.example.demo.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.example.demo.model.AskResponse;
import java.util.List;

@Service
public class RagService {
    private final VectorStore store;
    private final GeminiRestService gemini;
    private final int topK;

    public RagService(VectorStore store, GeminiRestService gemini, @Value("${rag.top.k:4}") int topK) {
        this.store = store; this.gemini = gemini; this.topK = topK;
    }

    public AskResponse ask(String question) throws Exception {
        float[] q = gemini.embed(question);
        List<VectorStore.Scored> hits = store.topK(q, topK);

        StringBuilder ctx = new StringBuilder();
        for (VectorStore.Scored s : hits) {
            ctx.append("\n[Chunk #").append(s.id()).append(" / score=").append(String.format("%.3f", s.score())).append("]\n");
            ctx.append(s.text()).append("\n");
        }
        String prompt = "You are a helpful assistant. Answer the user's question **using only the context** below. "
                + "If the answer is not present, say you don't know.\n\n"
                + "=== CONTEXT START ===\n" + ctx + "=== CONTEXT END ===\n\n"
                + "Question: " + question + "\nAnswer:";
        String answer = gemini.chat(prompt);
        return new AskResponse(answer, hits.stream().map(s -> new AskResponse.SourceScore(s.id(), s.score())).toList());
    }
}
